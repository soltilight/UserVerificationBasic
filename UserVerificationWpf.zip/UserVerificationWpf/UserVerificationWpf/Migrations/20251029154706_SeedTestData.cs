﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace UserVerificationWpf.Migrations
{
    public partial class SeedTestData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Вставить пользователей
            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "login", "hash_password", "is_superuser" },
                values: new object[,]
                {
                    { "alice", "5723360ef11043a879520412e9ad897e0ebcb99cc820ec363bfecc9d751a1a99", true },
                    { "admin", "9b8769a4a742959a2d0298c36fb70623f2dfacda8436237df08d8dfd5b37374c", true },
                    { "user1", "0a041b9462caa4a31bac3567e0b6e6fd9100787db2ab433d96f6d178cabfce90", false },
                    { "user2", "0a041b9462caa4a31bac3567e0b6e6fd9100787db2ab433d96f6d178cabfce90", false }
                });

            // Вставить сервисы
            migrationBuilder.InsertData(
                table: "Services",
                columns: new[] { "name", "description" },
                values: new object[,]
                {
                    { "Google", "Поисковая система и почтовый сервис" },
                    { "GitHub", "Платформа для хостинга IT-проектов" },
                    { "Microsoft", "Корпорация, облачные сервисы" },
                    { "Amazon", "Интернет-магазин и облачные сервисы" },
                    { "Facebook", "Социальная сеть" }
                });

            // Вставить учетные данные (ID пользователей будут 1-4, сервисов 1-5)
            migrationBuilder.InsertData(
                table: "Credential",
                columns: new[] { "login", "password", "users_id", "service_id" },
                values: new object[,]
                {
                    // Alice (id: 1)
                    { "alice@gmail.com", "alicepass", 1, 1 },
                    { "alice_gh", "alicegithub", 1, 2 },
                    
                    // Admin (id: 2)
                    { "admin@gmail.com", "pass123", 2, 1 },
                    { "admin", "githubpass", 2, 2 },
                    { "admin@outlook.com", "microsoft123", 2, 3 },
                    
                    // User1 (id: 3)
                    { "user1@gmail.com", "user1pass", 3, 1 },
                    { "user1_dev", "devpassword", 3, 2 },
                    { "user1@amazon.com", "amazon123", 3, 4 },
                    
                    // User2 (id: 4)
                    { "user2@gmail.com", "user2pass", 4, 1 },
                    { "user2_work", "workpass", 4, 3 },
                    { "user2_fb", "fbpassword", 4, 5 }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Удалить данные в обратном порядке
            migrationBuilder.DeleteData(
                table: "Credential",
                keyColumn: "id",
                keyValues: new object[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 });

            migrationBuilder.DeleteData(
                table: "Services",
                keyColumn: "id",
                keyValues: new object[] { 1, 2, 3, 4, 5 });

            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "id",
                keyValues: new object[] { 1, 2, 3, 4 });
        }
    }
}