﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace UserVerificationWpf.Migrations
{
    /// <inheritdoc />
    public partial class Init : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Services",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    description = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Services", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    login = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    hash_password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    is_superuser = table.Column<bool>(type: "bit", nullable: false) // Имя столбца: is_superuser
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Credential",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    login = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    users_id = table.Column<int>(type: "int", nullable: false),
                    service_id = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Credential", x => x.id);
                    table.ForeignKey(
                        name: "FK_Credential_Services_service_id",
                        column: x => x.service_id,
                        principalTable: "Services",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Credential_Users_users_id",
                        column: x => x.users_id,
                        principalTable: "Users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Credential_service_id",
                table: "Credential",
                column: "service_id");

            migrationBuilder.CreateIndex(
                name: "IX_Credential_users_id",
                table: "Credential",
                column: "users_id");

            // ИСПРАВЛЕННАЯ ВСТАВКА ДАННЫХ - используем правильное имя столбца
            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "login", "hash_password", "is_superuser" }, // Исправлено: is_superuser
                values: new object[,]
                {
                    { "alice", "5723360ef11043a879520412e9ad897e0ebcb99cc820ec363bfecc9d751a1a99", true },
                    { "admin", "9b8769a4a742959a2d0298c36fb70623f2dfacda8436237df08d8dfd5b37374c", true },
                    { "user1", "0a041b9462caa4a31bac3567e0b6e6fd9100787db2ab433d96f6d178cabfce90", false },
                    { "user2", "0a041b9462caa4a31bac3567e0b6e6fd9100787db2ab433d96f6d178cabfce90", false }
                });

            migrationBuilder.InsertData(
                table: "Services",
                columns: new[] { "name", "description" },
                values: new object[,]
                {
                    { "Google", "Поисковая система и почтовый сервис" },
                    { "GitHub", "Платформа для хостинга IT-проектов" },
                    { "Microsoft", "Корпорация, облачные сервисы" },
                    { "Amazon", "Интернет-магазин и облачные сервисы" },
                    { "Facebook", "Социальная сеть" }
                });

            // ОБНОВЛЕННЫЕ ID для Credential (учтите порядок вставки Users)
            migrationBuilder.InsertData(
                table: "Credential",
                columns: new[] { "login", "password", "users_id", "service_id" },
                values: new object[,]
                {
                    // Alice (id: 1)
                    { "alice@gmail.com", "alicepass", 1, 1 },
                    { "alice_gh", "alicegithub", 1, 2 },
                    
                    // Admin (id: 2)
                    { "admin@gmail.com", "pass123", 2, 1 },
                    { "admin", "githubpass", 2, 2 },
                    { "admin@outlook.com", "microsoft123", 2, 3 },
                    
                    // User1 (id: 3)
                    { "user1@gmail.com", "user1pass", 3, 1 },
                    { "user1_dev", "devpassword", 3, 2 },
                    { "user1@amazon.com", "amazon123", 3, 4 },
                    
                    // User2 (id: 4)
                    { "user2@gmail.com", "user2pass", 4, 1 },
                    { "user2_work", "workpass", 4, 3 },
                    { "user2_fb", "fbpassword", 4, 5 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Удаление данных в правильном порядке
            migrationBuilder.DeleteData(
                table: "Credential",
                keyColumn: "id",
                keyValues: new object[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 });

            migrationBuilder.DeleteData(
                table: "Services",
                keyColumn: "id",
                keyValues: new object[] { 1, 2, 3, 4, 5 });

            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "id",
                keyValues: new object[] { 1, 2, 3, 4 });

            migrationBuilder.DropTable(
                name: "Credential");

            migrationBuilder.DropTable(
                name: "Services");

            migrationBuilder.DropTable(
                name: "Users");
        }
    }
}