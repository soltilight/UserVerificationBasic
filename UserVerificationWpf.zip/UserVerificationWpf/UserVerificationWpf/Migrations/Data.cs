﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
#nullable disable

namespace UserVerificationWpf.Migrations
{
    public partial class AddTestData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "login", "hash_password", "is_super_user" },
                values: new object[,]
                {
                    {"alice","5723360ef11043a879520412e9ad897e0ebcb99cc820ec363bfecc9d751a1a99",true },
                    { "admin", "9b8769a4a742959a2d0298c36fb70623f2dfacda8436237df08d8dfd5b37374c", true },
                    { "user1", "0a041b9462caa4a31bac3567e0b6e6fd9100787db2ab433d96f6d178cabfce90", false },
                    { "user2", "0a041b9462caa4a31bac3567e0b6e6fd9100787db2ab433d96f6d178cabfce90", false }
                });

            migrationBuilder.InsertData(
                table: "Services",
                columns: new[] { "name", "description" },
                values: new object[,]
                {
                    { "Google", "Поисковая система и почтовый сервис" },
                    { "GitHub", "Платформа для хостинга IT-проектов" },
                    { "Microsoft", "Корпорация, облачные сервисы" },
                    { "Amazon", "Интернет-магазин и облачные сервисы" },
                    { "Facebook", "Социальная сеть" }
                });

            migrationBuilder.InsertData(
                table: "Credential",
                columns: new[] { "login", "password", "users_id", "service_id" },
                values: new object[,]
                {
                    { "admin@gmail.com", "pass123", 1, 1 },
                    { "admin", "githubpass", 1, 2 },
                    { "admin@outlook.com", "microsoft123", 1, 3 },
                    { "user1@gmail.com", "user1pass", 2, 1 },
                    { "user1_dev", "devpassword", 2, 2 },
                    { "user1@amazon.com", "amazon123", 2, 4 },
                    { "user2@gmail.com", "user2pass", 3, 1 },
                    { "user2_work", "workpass", 3, 3 },
                    { "user2_fb", "fbpassword", 3, 5 }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Credential",
                keyColumn: "id",
                keyValues: new object[] { 1, 2, 3, 4, 5, 6, 7, 8, 9 });

            migrationBuilder.DeleteData(
                table: "Services",
                keyColumn: "id",
                keyValues: new object[] { 1, 2, 3, 4, 5 });

            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "id",
                keyValues: new object[] { 1, 2, 3 });
        }
    }
}