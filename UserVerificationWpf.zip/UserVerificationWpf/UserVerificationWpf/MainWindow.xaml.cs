﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using UserVerificationWpf.BdTables;


namespace UserVerificationWpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void EditUserConfirmBtn_Click(object sender, RoutedEventArgs e)
        {

        }

        private void EditUserCancelBtn_Click(object sender, RoutedEventArgs e)
        {

        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            LoginTextBox.Text = "";
            Password.Text = "";
            ServiceNameTextBox.Text = "";
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {

            
            using (ApplicationDbContextInit db = new ApplicationDbContextInit())
            {
                CrudeOperations crude = new CrudeOperations(db);

               
                string hashedPassword = HashPassword(Password.Text);
                if (crude.SuperUserTest(LoginTextBox.Text, hashedPassword))
                {

                    SuperUserRedactor();
                    return;
                }

                if (crude.ValidateUser(LoginTextBox.Text, hashedPassword) && crude.ServiceExists(ServiceNameTextBox.Text))
                {
                    MessageBox.Show($"Verification complete, welcome to {ServiceNameTextBox.Text} ");
                }
                else
                {
                    MessageBox.Show("Incorrect Password, login or Service Provider");
                }
            }
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            
            using (ApplicationDbContextInit db = new ApplicationDbContextInit())
            {
                CrudeOperations crude = new CrudeOperations(db);
                string hashedPassword = HashPassword(Password.Text);
                Users newUser = new Users
                {
                    login = LoginTextBox.Text,
                    hash_password = hashedPassword,
                    is_superuser = false
                };
                if (crude.ServiceExists(ServiceNameTextBox.Text))
                {
                    if (crude.CreateUser(newUser))
                    {
                        MessageBox.Show("User created successfully");
                        return;
                    }
                    else
                    {
                        MessageBox.Show("User creation failed");
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Service Provider does not exist");
                }
                    

            }


        }
        private string HashPassword(string password)
        {
            using (System.Security.Cryptography.SHA256 sha256 = System.Security.Cryptography.SHA256.Create())
            {
                byte[] bytes = System.Text.Encoding.UTF8.GetBytes(password);
                byte[] hash = sha256.ComputeHash(bytes);
                return BitConverter.ToString(hash).Replace("-", "").ToLower();
            }
        }
        private void SuperUserRedactor()
        {
            SuperUserUI redactor= new SuperUserUI();
            redactor.Show();
        }
    }
}