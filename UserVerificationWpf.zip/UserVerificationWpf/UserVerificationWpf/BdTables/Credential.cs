﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserVerificationWpf.BdTables
{
    internal class Credential
    {
        public int id { get; set; }
        public string login { get; set; }
        public string password { get; set; }
        public int users_id { get; set; }
        public int service_id { get; set; }
        public Users  User { get; set; }
        public Service  Service { get; set; }

        public override string ToString()
        {
            return $"{id}: {login} - {password} (User: {users_id}, Service: {service_id})";
        }
    }
}
