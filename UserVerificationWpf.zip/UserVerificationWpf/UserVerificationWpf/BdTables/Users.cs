﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserVerificationWpf.BdTables
{
    public class Users
    {
        public int id { get; set; }
        public string login { get; set; }
        public string hash_password { get; set; }
        public bool is_superuser { get; set; } = false;
        public override string ToString()
        {
            return $"{id}-{login}-{hash_password}";
        }
    }
}
