﻿using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UserVerificationWpf.BdTables;
using Microsoft.EntityFrameworkCore;

namespace UserVerificationWpf
{
    public partial class SuperUserUI : Window
    {
        private CrudeOperations _crudeOperations;
        private ApplicationDbContextInit _context;

        public SuperUserUI()
        {
            InitializeComponent();
            _context = new ApplicationDbContextInit();
            _crudeOperations = new CrudeOperations(_context);
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(login))
            {
                MessageBox.Show("Пожалуйста, введите логин пользователя для обновления.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var existingUser = _crudeOperations.GetUserByLogin(login);
            if (existingUser == null)
            {
                MessageBox.Show($"Пользователь с логином '{login}' не найден.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!string.IsNullOrEmpty(password))
            {
                existingUser.hash_password = password;
            }

            bool success = _crudeOperations.UpdateUser(existingUser);

            if (success)
            {
                MessageBox.Show($"Пользователь '{login}' успешно обновлен.", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                ClearFields();
            }
            else
            {
                MessageBox.Show($"Не удалось обновить пользователя '{login}'.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            string login = txtLogin.Text.Trim();

            if (string.IsNullOrEmpty(login))
            {
                MessageBox.Show("Пожалуйста, введите логин пользователя для удаления.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var userToDelete = _crudeOperations.GetUserByLogin(login);
            if (userToDelete == null)
            {
                MessageBox.Show($"Пользователь с логином '{login}' не найден.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (userToDelete.is_superuser)
            {
                MessageBox.Show("Нельзя удалить суперпользователя.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            MessageBoxResult result = MessageBox.Show(
                $"Вы уверены, что хотите удалить пользователя '{login}'?",
                "Подтверждение удаления",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                bool success = _crudeOperations.DeleteUserByLogin(login);

                if (success)
                {
                    MessageBox.Show($"Пользователь '{login}' успешно удален.", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    ClearFields();
                }
                else
                {
                    MessageBox.Show($"Не удалось удалить пользователя '{login}'.", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void btnCreate_Click(object sender, RoutedEventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Пожалуйста, заполните все поля (логин и пароль).", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (_crudeOperations.UserExists(login))
            {
                MessageBox.Show($"Пользователь с логином '{login}' уже существует.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var newUser = new Users
            {
                login = login,
                hash_password = password,
                is_superuser = false
            };

            bool success = _crudeOperations.CreateUser(newUser);

            if (success)
            {
                MessageBox.Show($"Пользователь '{login}' успешно создан.", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                ClearFields();
            }
            else
            {
                MessageBox.Show($"Не удалось создать пользователя '{login}'.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ClearFields()
        {
            txtLogin.Clear();
            txtPassword.Clear();
            txtLogin.Focus();
        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            _crudeOperations?.Dispose();
            _context?.Dispose();
        }
    }
}