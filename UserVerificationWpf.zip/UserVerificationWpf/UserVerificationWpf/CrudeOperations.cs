﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using UserVerificationWpf.BdTables;

namespace UserVerificationWpf
{
    internal class CrudeOperations
    { 
        ApplicationDbContextInit _context = new ApplicationDbContextInit();

        public CrudeOperations(ApplicationDbContextInit db)
        {
             _context = db;
           
        }
        public bool SuperUserTest(string login, string hash_password)
        {
            return _context.Users.Any(u => u.login == login && u.hash_password == hash_password && u.is_superuser);
        }

        public Users GetUserByLogin(string login)
        {
            return _context.Users.FirstOrDefault(u => u.login == login);
        }

        public bool CreateUser(Users user)
        {
            try
            {
                _context.Users.Add(user);
                _context.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool UpdateUser(Users user)
        {
            try
            {
                _context.Users.Update(user);
                _context.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool DeleteUserByLogin(string login)
        {
            try
            {
                var user = _context.Users.FirstOrDefault(u => u.login == login);
                if (user != null && !user.is_superuser)
                {
                    _context.Users.Remove(user);
                    _context.SaveChanges();
                    return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public Service GetServiceByName(string name)
        {
            return _context.Services.FirstOrDefault(s => s.name == name);
        }

        public List<Credential> GetUserCredentials(int userId)
        {
            return _context.Credential
                .Include(c => c.User)
                .Include(c => c.Service)
                .Where(c => c.users_id == userId)
                .ToList();
        }

        public bool CreateCredential(Credential credential)
        {
            try
            {
                _context.Credential.Add(credential);
                _context.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool UpdateCredential(Credential credential)
        {
            try
            {
                _context.Credential.Update(credential);
                _context.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool DeleteCredential(int id)
        {
            try
            {
                var credential = _context.Credential.FirstOrDefault(c => c.id == id);
                if (credential != null)
                {
                    _context.Credential.Remove(credential);
                    _context.SaveChanges();
                    return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool UserExists(string login)
        {
            return _context.Users.Any(u => u.login == login);
        }

        public bool ServiceExists(string name)
        {
            return _context.Services.Any(s => s.name == name);
        }

        public bool ValidateUser(string login, string hashPassword)
        {
            return _context.Users.Any(u => u.login == login && u.hash_password == hashPassword);
        }

        public void Dispose()
        {
            _context?.Dispose();
        }
    }
}