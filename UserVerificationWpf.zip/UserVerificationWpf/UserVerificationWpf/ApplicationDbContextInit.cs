﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserVerificationWpf.BdTables;

namespace UserVerificationWpf
{
    internal class ApplicationDbContextInit : DbContext
    {
        public DbSet<Users> Users { get; set; }
        public DbSet<Service> Services { get; set; }
        public DbSet<Credential> Credential { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string connectionString = @"
                Data Source=(localdb)\mssqllocaldb;
                Integrated Security=SSPI;
                Initial Catalog=UserVerification;
                Timeout=5;
                TrustServerCertificate=True;
            ";
            optionsBuilder.UseSqlServer(connectionString);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Credential>()
                .HasOne(c => c.User)
                .WithMany()
                .HasForeignKey(c => c.users_id)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Credential>()
                .HasOne(c => c.Service)
                .WithMany()
                .HasForeignKey(c => c.service_id)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
